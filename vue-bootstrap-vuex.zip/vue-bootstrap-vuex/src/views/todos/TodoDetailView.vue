<template>
  <div>
    <h1>디테일</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>