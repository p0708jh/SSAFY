<template>
  <div id="app">
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/board">Board</router-link>
    </nav>
    <router-view/>
  </div>
</template>


<style>

</style>