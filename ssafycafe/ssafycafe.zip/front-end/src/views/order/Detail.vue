<template>
  <div>
    주문 디테일
  </div>
</template>

<script>


export default {
  data(){
    return {

    }
  }
};
</script>

<style scoped>

</style>